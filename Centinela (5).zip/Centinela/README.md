# CENTINELA · App de Fiscalización (Android nativo)

App nativa en **Kotlin + Jetpack Compose (Material 3)** que implementa el flujo "por caseta":
login → empresa / instalación / turno → cantidad de casetas → guardias de cada caseta (nombre + hasta 5 fotos) →
fotos y observación de cada caseta (hasta 5) → resumen → envío al cliente APS (simulado) → confirmación.

Incluye historial, detalle de cada fiscalización y un **visor de base de datos** (acepta `SELECT`, `SHOW TABLES`, `DESCRIBE tabla`).

## Base de datos (MySQL simulada)
- En el teléfono, los datos se guardan en una base local (`centinela.db`) con **las mismas 11 tablas, columnas y relaciones** del esquema MySQL.
- `database/centinela_mysql.sql` es el script real para MySQL 8 (XAMPP, Workbench o phpMyAdmin), con los mismos datos de prueba.
- Único ajuste al diagrama: `guardias_fiscalizacion` tiene la columna `caseta_id`, necesaria para saber a qué caseta pertenece cada guardia.
- Toda la lógica de datos está en `data/CentinelaRepository.kt`: para conectar un MySQL real más adelante, se reemplaza esa clase por llamadas a una API.

Usuarios de prueba: `supervisor / 1234` (ve sus instalaciones asignadas) y `admin / admin123` (ve todo).

## Probar en tu teléfono Android

### 1. Preparar el computador
1. Instala la versión más reciente de **Android Studio** (developer.android.com/studio).
2. Descomprime `Centinela.zip`.
3. En Android Studio: **File → Open** → elige la carpeta `Centinela` (la que contiene `settings.gradle.kts`).
4. Espera a que termine el **Gradle Sync** (la primera vez descarga librerías; necesita internet y puede tardar varios minutos).
   - Si aparece un aviso para actualizar el "Android Gradle Plugin", puedes aceptarlo o ignorarlo.
   - Si pide instalar el SDK 35, acepta.

### 2. Preparar el teléfono
1. **Ajustes → Acerca del teléfono** (en Samsung: *Información de software*) → toca **7 veces "Número de compilación"** hasta que diga "Ahora eres desarrollador".
2. **Ajustes → Sistema → Opciones de desarrollador** → activa **Depuración por USB**.
3. Conecta el teléfono por cable USB (que sea cable de datos) y acepta el aviso **"¿Permitir depuración por USB?"**.

### 3. Instalar y ejecutar
1. En la barra superior de Android Studio, elige tu teléfono en la lista de dispositivos.
2. Presiona **Run ▶** (o Shift + F10). La app se instala y abre sola con el nombre **Centinela**.

**Alternativa sin cable (APK):** Build → Build App Bundle(s) / APK(s) → Build APK(s) → "locate".
Envía `app-debug.apk` a tu teléfono (Drive, WhatsApp, correo), ábrelo y permite "Instalar apps desconocidas".

**Alternativa Wi-Fi (Android 11+):** Opciones de desarrollador → Depuración inalámbrica → en Android Studio: Device Manager → *Pair devices using Wi-Fi*.

### 4. Guion de prueba
1. Ingresa con `supervisor / 1234`.
2. **Comenzar** → elige *Seguridad Total Ltda.* → *Centro Logístico* → turno *Mañana* → Siguiente.
3. Casetas: **2**.
4. Caseta 1: 2 guardias → nombres + fotos con **Cámara** o **Galería** → fotos de la caseta + observación.
5. Caseta 2: 1 guardia → igual.
6. En el resumen, deja activado **Enviar al cliente APS** → **Finalizar fiscalización**.
7. Vuelve al inicio: aparece en el historial; tócala para ver el detalle con fotos.
8. **Ver base de datos** → toca `fiscalizaciones`, `guardias_fiscalizacion`, `envios_aps`, o escribe `SHOW TABLES`.
9. Cierra sesión y entra con `admin / admin123`: ve todas las fiscalizaciones y la instalación *Condominio Los Robles*.

### Problemas comunes
- **Teléfono no aparece:** cambia el modo USB a "Transferencia de archivos", revisa el cable y vuelve a aceptar la depuración.
- **Error de JDK/Gradle:** File → Settings → Build Tools → Gradle → Gradle JDK = *jbr-17* o *jbr-21*.
- **Reiniciar datos de prueba:** desinstala la app y vuelve a ejecutarla.
- Las fotos se guardan en la carpeta privada de la app (`files/fotos`), no en la galería.

## Estructura
```
app/src/main/java/cl/roang/centinela/
├── MainActivity.kt
├── data/   CentinelaDb.kt (esquema + datos), CentinelaRepository.kt (consultas), Models.kt
└── ui/     CentinelaViewModel.kt (flujo), CentinelaApp.kt, Fotos.kt, theme/, screens/
database/centinela_mysql.sql
```
