package cl.roang.centinela.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

/**
 * Base de datos local que SIMULA el esquema MySQL de CENTINELA.
 * Las tablas, columnas y relaciones son las mismas del archivo
 * database/centinela_mysql.sql, para que más adelante la app pueda
 * conectarse a un backend con MySQL real sin cambiar el modelo.
 */
class CentinelaDb(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        ESQUEMA.forEach { db.execSQL(it) }
        sembrarDatos(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        TABLAS.reversed().forEach { db.execSQL("DROP TABLE IF EXISTS $it") }
        onCreate(db)
    }

    private fun sembrarDatos(db: SQLiteDatabase) {
        val sqlUsuario =
            "INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo) VALUES (?, ?, ?, ?, 1)"
        db.execSQL(sqlUsuario, arrayOf<Any?>("Administrador CENTINELA", "admin", sha256("admin123"), "admin"))
        db.execSQL(sqlUsuario, arrayOf<Any?>("Supervisor Demo", "supervisor", sha256("1234"), "supervisor"))

        val empresas = listOf(
            "Seguridad Total Ltda." to "76.111.111-1",
            "Rentas Chile S.A." to "76.222.222-2",
            "Servicios Integrales SpA" to "76.333.333-3",
            "Grupo Protección Ltda." to "76.444.444-4"
        )
        empresas.forEach { (nombre, rut) ->
            db.execSQL("INSERT INTO empresas (nombre, rut, activo) VALUES (?, ?, 1)", arrayOf<Any?>(nombre, rut))
        }

        val instalaciones = listOf(
            Triple(1L, "Casa Matriz", "Av. Apoquindo 4500, Las Condes"),
            Triple(1L, "Planta Industrial", "Camino Lo Boza 120, Pudahuel"),
            Triple(1L, "Centro Logístico", "Av. Américo Vespucio 1500, Quilicura"),
            Triple(2L, "Sucursal Santiago", "Av. Libertador B. O'Higgins 1234, Santiago"),
            Triple(2L, "Sucursal Valparaíso", "Av. Brasil 2100, Valparaíso"),
            Triple(3L, "Sucursal Concepción", "Calle Barros Arana 800, Concepción"),
            Triple(3L, "Bodega Central", "Av. Departamental 3300, San Joaquín"),
            Triple(4L, "Edificio Corporativo", "Av. Providencia 2000, Providencia"),
            Triple(4L, "Condominio Los Robles", "Los Robles 450, La Florida")
        )
        instalaciones.forEach { (empresaId, nombre, direccion) ->
            db.execSQL(
                "INSERT INTO instalaciones (empresa_id, nombre, direccion, activo) VALUES (?, ?, ?, 1)",
                arrayOf<Any?>(empresaId, nombre, direccion)
            )
        }

        // El supervisor demo (id 2) tiene asignadas las instalaciones 1 a 8.
        // La 9 (Condominio Los Robles) solo la ve el administrador.
        (1..8).forEach { instalacionId ->
            db.execSQL(
                "INSERT INTO supervisor_instalaciones (supervisor_id, instalacion_id, activo) VALUES (2, ?, 1)",
                arrayOf<Any?>(instalacionId)
            )
        }

        val destinatarios = listOf(
            Triple(1L, "Jefatura APS Seguridad Total", "aps@seguridadtotal.demo"),
            Triple(2L, "Operaciones Rentas Chile", "aps@rentaschile.demo"),
            Triple(3L, "Control Servicios Integrales", "aps@serviciosintegrales.demo"),
            Triple(4L, "Gerencia Grupo Protección", "aps@grupoproteccion.demo")
        )
        destinatarios.forEach { (empresaId, nombre, correo) ->
            db.execSQL(
                "INSERT INTO destinatarios_aps (empresa_id, instalacion_id, nombre, correo, activo) VALUES (?, NULL, ?, ?, 1)",
                arrayOf<Any?>(empresaId, nombre, correo)
            )
        }
    }

    companion object {
        const val DB_NAME = "centinela.db"
        const val DB_VERSION = 1

        val TABLAS = listOf(
            "usuarios",
            "empresas",
            "instalaciones",
            "supervisor_instalaciones",
            "fiscalizaciones",
            "casetas_fiscalizacion",
            "guardias_fiscalizacion",
            "fotos_guardias",
            "fotos_casetas",
            "destinatarios_aps",
            "envios_aps"
        )

        private val ESQUEMA = listOf(
            """
            CREATE TABLE usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                usuario TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                rol TEXT NOT NULL CHECK (rol IN ('admin', 'supervisor')),
                activo INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE empresas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                rut TEXT NOT NULL UNIQUE,
                activo INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE instalaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empresa_id INTEGER NOT NULL REFERENCES empresas(id),
                nombre TEXT NOT NULL,
                direccion TEXT,
                activo INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE supervisor_instalaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supervisor_id INTEGER NOT NULL REFERENCES usuarios(id),
                instalacion_id INTEGER NOT NULL REFERENCES instalaciones(id),
                activo INTEGER NOT NULL DEFAULT 1,
                UNIQUE (supervisor_id, instalacion_id)
            )
            """,
            """
            CREATE TABLE fiscalizaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supervisor_id INTEGER NOT NULL REFERENCES usuarios(id),
                empresa_id INTEGER NOT NULL REFERENCES empresas(id),
                instalacion_id INTEGER NOT NULL REFERENCES instalaciones(id),
                turno TEXT NOT NULL CHECK (turno IN ('Mañana', 'Noche')),
                fecha_fiscalizacion TEXT NOT NULL,
                cantidad_guardias INTEGER NOT NULL DEFAULT 0,
                cantidad_casetas INTEGER NOT NULL DEFAULT 0,
                informacion_adicional TEXT,
                estado TEXT NOT NULL DEFAULT 'FINALIZADA',
                enviar_aps INTEGER NOT NULL DEFAULT 0
            )
            """,
            """
            CREATE TABLE casetas_fiscalizacion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fiscalizacion_id INTEGER NOT NULL REFERENCES fiscalizaciones(id) ON DELETE CASCADE,
                nombre TEXT NOT NULL,
                observacion TEXT
            )
            """,
            """
            CREATE TABLE guardias_fiscalizacion (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fiscalizacion_id INTEGER NOT NULL REFERENCES fiscalizaciones(id) ON DELETE CASCADE,
                caseta_id INTEGER REFERENCES casetas_fiscalizacion(id) ON DELETE CASCADE,
                nombre TEXT NOT NULL,
                observacion TEXT
            )
            """,
            """
            CREATE TABLE fotos_guardias (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guardia_id INTEGER NOT NULL REFERENCES guardias_fiscalizacion(id) ON DELETE CASCADE,
                ruta_foto TEXT NOT NULL,
                fecha_foto TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE fotos_casetas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                caseta_id INTEGER NOT NULL REFERENCES casetas_fiscalizacion(id) ON DELETE CASCADE,
                ruta_foto TEXT NOT NULL,
                fecha_foto TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE destinatarios_aps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                empresa_id INTEGER NOT NULL REFERENCES empresas(id),
                instalacion_id INTEGER REFERENCES instalaciones(id),
                nombre TEXT NOT NULL,
                correo TEXT NOT NULL,
                activo INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE envios_aps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fiscalizacion_id INTEGER NOT NULL REFERENCES fiscalizaciones(id) ON DELETE CASCADE,
                destinatario_id INTEGER REFERENCES destinatarios_aps(id),
                correo_destino TEXT NOT NULL,
                estado TEXT NOT NULL DEFAULT 'PENDIENTE',
                intentos INTEGER NOT NULL DEFAULT 0,
                fecha_envio TEXT,
                ultimo_error TEXT
            )
            """
        ).map { it.trimIndent() }

        fun sha256(texto: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest(texto.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
    }
}
