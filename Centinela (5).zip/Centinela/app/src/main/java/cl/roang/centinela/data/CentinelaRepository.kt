package cl.roang.centinela.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.DatabaseUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Todas las consultas de la app pasan por aquí. Si mañana se conecta un
 * backend con MySQL real (API REST), solo se reemplaza esta clase.
 */
class CentinelaRepository(context: Context) {

    private val helper = CentinelaDb(context.applicationContext)
    private val db get() = helper.writableDatabase

    fun login(usuario: String, password: String): Usuario? {
        return db.rawQuery(
            "SELECT id, nombre, usuario, rol FROM usuarios WHERE usuario = ? AND password_hash = ? AND activo = 1",
            arrayOf(usuario.trim(), CentinelaDb.sha256(password))
        ).use { c ->
            if (c.moveToFirst()) Usuario(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)) else null
        }
    }

    fun empresas(): List<Empresa> =
        db.rawQuery("SELECT id, nombre, rut FROM empresas WHERE activo = 1 ORDER BY nombre", null).use { c ->
            val lista = mutableListOf<Empresa>()
            while (c.moveToNext()) lista.add(Empresa(c.getLong(0), c.getString(1), c.getString(2)))
            lista
        }

    fun instalaciones(empresaId: Long, usuario: Usuario): List<Instalacion> {
        val sql: String
        val args: Array<String>
        if (usuario.esAdmin) {
            sql = """
                SELECT i.id, i.empresa_id, i.nombre, IFNULL(i.direccion, '')
                FROM instalaciones i
                WHERE i.empresa_id = ? AND i.activo = 1
                ORDER BY i.nombre
            """.trimIndent()
            args = arrayOf(empresaId.toString())
        } else {
            sql = """
                SELECT i.id, i.empresa_id, i.nombre, IFNULL(i.direccion, '')
                FROM instalaciones i
                JOIN supervisor_instalaciones si ON si.instalacion_id = i.id AND si.activo = 1
                WHERE i.empresa_id = ? AND i.activo = 1 AND si.supervisor_id = ?
                ORDER BY i.nombre
            """.trimIndent()
            args = arrayOf(empresaId.toString(), usuario.id.toString())
        }
        return db.rawQuery(sql, args).use { c ->
            val lista = mutableListOf<Instalacion>()
            while (c.moveToNext()) lista.add(Instalacion(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3)))
            lista
        }
    }

    /** Guarda toda la fiscalización en una transacción. Devuelve (id, envíos APS simulados). */
    fun guardarFiscalizacion(
        usuario: Usuario,
        empresa: Empresa,
        instalacion: Instalacion,
        turno: String,
        casetas: List<CasetaDraft>,
        informacionAdicional: String,
        enviarAps: Boolean
    ): Pair<Long, Int> {
        val ahora = ahora()
        val d = db
        d.beginTransaction()
        try {
            val fiscalizacionId = d.insertOrThrow("fiscalizaciones", null, ContentValues().apply {
                put("supervisor_id", usuario.id)
                put("empresa_id", empresa.id)
                put("instalacion_id", instalacion.id)
                put("turno", turno)
                put("fecha_fiscalizacion", ahora)
                put("cantidad_guardias", casetas.sumOf { it.guardias.size })
                put("cantidad_casetas", casetas.size)
                put("informacion_adicional", informacionAdicional.trim())
                put("estado", "FINALIZADA")
                put("enviar_aps", if (enviarAps) 1 else 0)
            })

            casetas.forEach { caseta ->
                val casetaId = d.insertOrThrow("casetas_fiscalizacion", null, ContentValues().apply {
                    put("fiscalizacion_id", fiscalizacionId)
                    put("nombre", caseta.nombre.trim())
                    put("observacion", caseta.observacion.trim())
                })
                caseta.fotos.forEach { ruta ->
                    d.insertOrThrow("fotos_casetas", null, ContentValues().apply {
                        put("caseta_id", casetaId)
                        put("ruta_foto", ruta)
                        put("fecha_foto", ahora)
                    })
                }
                caseta.guardias.forEach { guardia ->
                    val guardiaId = d.insertOrThrow("guardias_fiscalizacion", null, ContentValues().apply {
                        put("fiscalizacion_id", fiscalizacionId)
                        put("caseta_id", casetaId)
                        put("nombre", guardia.nombre.trim())
                        put("observacion", guardia.observacion.trim())
                    })
                    guardia.fotos.forEach { ruta ->
                        d.insertOrThrow("fotos_guardias", null, ContentValues().apply {
                            put("guardia_id", guardiaId)
                            put("ruta_foto", ruta)
                            put("fecha_foto", ahora)
                        })
                    }
                }
            }

            var envios = 0
            if (enviarAps) {
                // Simulación del envío al cliente APS: se registra en envios_aps como ENVIADO.
                d.rawQuery(
                    """
                    SELECT id, correo FROM destinatarios_aps
                    WHERE activo = 1 AND empresa_id = ? AND (instalacion_id IS NULL OR instalacion_id = ?)
                    """.trimIndent(),
                    arrayOf(empresa.id.toString(), instalacion.id.toString())
                ).use { c ->
                    while (c.moveToNext()) {
                        d.insertOrThrow("envios_aps", null, ContentValues().apply {
                            put("fiscalizacion_id", fiscalizacionId)
                            put("destinatario_id", c.getLong(0))
                            put("correo_destino", c.getString(1))
                            put("estado", "ENVIADO")
                            put("intentos", 1)
                            put("fecha_envio", ahora)
                            putNull("ultimo_error")
                        })
                        envios++
                    }
                }
            }
            d.setTransactionSuccessful()
            return fiscalizacionId to envios
        } finally {
            d.endTransaction()
        }
    }

    private val sqlResumen = """
        SELECT f.id, e.nombre, i.nombre, f.turno, f.fecha_fiscalizacion, f.cantidad_casetas,
               f.cantidad_guardias, f.estado, f.enviar_aps, u.nombre, IFNULL(f.informacion_adicional, '')
        FROM fiscalizaciones f
        JOIN empresas e ON e.id = f.empresa_id
        JOIN instalaciones i ON i.id = f.instalacion_id
        JOIN usuarios u ON u.id = f.supervisor_id
    """.trimIndent()

    private fun leerResumen(c: Cursor) = FiscalizacionResumen(
        id = c.getLong(0),
        empresa = c.getString(1),
        instalacion = c.getString(2),
        turno = c.getString(3),
        fecha = c.getString(4),
        cantidadCasetas = c.getInt(5),
        cantidadGuardias = c.getInt(6),
        estado = c.getString(7),
        enviarAps = c.getInt(8) == 1,
        supervisor = c.getString(9),
        informacionAdicional = c.getString(10)
    )

    fun historial(usuario: Usuario): List<FiscalizacionResumen> {
        val sql = if (usuario.esAdmin) "$sqlResumen ORDER BY f.id DESC"
        else "$sqlResumen WHERE f.supervisor_id = ? ORDER BY f.id DESC"
        val args = if (usuario.esAdmin) null else arrayOf(usuario.id.toString())
        return db.rawQuery(sql, args).use { c ->
            val lista = mutableListOf<FiscalizacionResumen>()
            while (c.moveToNext()) lista.add(leerResumen(c))
            lista
        }
    }

    fun detalle(id: Long): FiscalizacionDetalle? {
        val d = db
        val resumen = d.rawQuery("$sqlResumen WHERE f.id = ?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) leerResumen(c) else null
        } ?: return null

        val casetas = mutableListOf<CasetaDetalle>()
        d.rawQuery(
            "SELECT id, nombre, IFNULL(observacion, '') FROM casetas_fiscalizacion WHERE fiscalizacion_id = ? ORDER BY id",
            arrayOf(id.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val casetaId = c.getLong(0).toString()
                val fotosCaseta = listaTexto("SELECT ruta_foto FROM fotos_casetas WHERE caseta_id = ? ORDER BY id", casetaId)
                val guardias = mutableListOf<GuardiaDetalle>()
                d.rawQuery(
                    "SELECT id, nombre, IFNULL(observacion, '') FROM guardias_fiscalizacion WHERE caseta_id = ? ORDER BY id",
                    arrayOf(casetaId)
                ).use { g ->
                    while (g.moveToNext()) {
                        val fotos = listaTexto(
                            "SELECT ruta_foto FROM fotos_guardias WHERE guardia_id = ? ORDER BY id",
                            g.getLong(0).toString()
                        )
                        guardias.add(GuardiaDetalle(g.getString(1), g.getString(2), fotos))
                    }
                }
                casetas.add(CasetaDetalle(c.getString(1), c.getString(2), fotosCaseta, guardias))
            }
        }

        val envios = d.rawQuery(
            "SELECT correo_destino, estado, intentos, IFNULL(fecha_envio, '') FROM envios_aps WHERE fiscalizacion_id = ? ORDER BY id",
            arrayOf(id.toString())
        ).use { c ->
            val lista = mutableListOf<EnvioAps>()
            while (c.moveToNext()) lista.add(EnvioAps(c.getString(0), c.getString(1), c.getInt(2), c.getString(3)))
            lista
        }
        return FiscalizacionDetalle(resumen, casetas, envios)
    }

    private fun listaTexto(sql: String, arg: String): List<String> =
        db.rawQuery(sql, arrayOf(arg)).use { c ->
            val lista = mutableListOf<String>()
            while (c.moveToNext()) lista.add(c.getString(0))
            lista
        }

    fun conteoTablas(): List<Pair<String, Long>> =
        CentinelaDb.TABLAS.map { it to DatabaseUtils.queryNumEntries(db, it) }

    /**
     * Visor de solo lectura. Acepta SELECT y traduce dos comandos típicos de MySQL:
     * SHOW TABLES y DESCRIBE <tabla>.
     */
    fun consultar(sqlOriginal: String): TablaResultado {
        val sql = sqlOriginal.trim().trimEnd(';').trim()
        val describe = Regex("^(DESCRIBE|DESC)\\s+(\\w+)$", RegexOption.IGNORE_CASE).find(sql)
        val traducida = when {
            sql.equals("SHOW TABLES", ignoreCase = true) ->
                "SELECT name AS Tables_in_centinela FROM sqlite_master WHERE type = 'table' " +
                    "AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name"
            describe != null -> {
                val tabla = describe.groupValues[2]
                require(tabla in CentinelaDb.TABLAS) { "La tabla '$tabla' no existe." }
                "SELECT name AS Field, type AS Type, CASE WHEN \"notnull\" = 1 THEN 'NO' ELSE 'YES' END AS \"Null\", " +
                    "CASE WHEN pk = 1 THEN 'PRI' ELSE '' END AS \"Key\", dflt_value AS \"Default\" FROM pragma_table_info('$tabla')"
            }
            sql.startsWith("SELECT", ignoreCase = true) -> sql
            else -> throw IllegalArgumentException(
                "Este visor es de solo lectura. Usa SELECT, SHOW TABLES o DESCRIBE <tabla>."
            )
        }
        return db.rawQuery(traducida, null).use { c ->
            val columnas = c.columnNames.toList()
            val filas = mutableListOf<List<String>>()
            while (c.moveToNext() && filas.size < 200) {
                filas.add((0 until c.columnCount).map { i -> if (c.isNull(i)) "NULL" else c.getString(i) })
            }
            TablaResultado(columnas, filas)
        }
    }

    private fun ahora(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
}
