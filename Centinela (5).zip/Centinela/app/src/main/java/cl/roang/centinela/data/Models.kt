package cl.roang.centinela.data

data class Usuario(val id: Long, val nombre: String, val usuario: String, val rol: String) {
    val esAdmin: Boolean get() = rol == "admin"
}

data class Empresa(val id: Long, val nombre: String, val rut: String)

data class Instalacion(val id: Long, val empresaId: Long, val nombre: String, val direccion: String)

/** Borradores en memoria mientras el supervisor completa el flujo. */
data class GuardiaDraft(
    val nombre: String = "",
    val observacion: String = "",
    val fotos: List<String> = emptyList()
)

data class CasetaDraft(
    val nombre: String,
    val guardias: List<GuardiaDraft> = listOf(GuardiaDraft()),
    val fotos: List<String> = emptyList(),
    val observacion: String = ""
)

data class FiscalizacionResumen(
    val id: Long,
    val empresa: String,
    val instalacion: String,
    val turno: String,
    val fecha: String,
    val cantidadCasetas: Int,
    val cantidadGuardias: Int,
    val estado: String,
    val enviarAps: Boolean,
    val supervisor: String,
    val informacionAdicional: String
)

data class GuardiaDetalle(val nombre: String, val observacion: String, val fotos: List<String>)

data class CasetaDetalle(
    val nombre: String,
    val observacion: String,
    val fotos: List<String>,
    val guardias: List<GuardiaDetalle>
)

data class EnvioAps(val correo: String, val estado: String, val intentos: Int, val fecha: String)

data class FiscalizacionDetalle(
    val resumen: FiscalizacionResumen,
    val casetas: List<CasetaDetalle>,
    val envios: List<EnvioAps>
)

data class TablaResultado(val columnas: List<String>, val filas: List<List<String>>)
