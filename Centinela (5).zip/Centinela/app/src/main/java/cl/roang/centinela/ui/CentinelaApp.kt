package cl.roang.centinela.ui

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import cl.roang.centinela.ui.screens.BaseDatosScreen
import cl.roang.centinela.ui.screens.CantidadCasetasScreen
import cl.roang.centinela.ui.screens.ConfirmacionScreen
import cl.roang.centinela.ui.screens.DatosScreen
import cl.roang.centinela.ui.screens.DetalleScreen
import cl.roang.centinela.ui.screens.FotosCasetaScreen
import cl.roang.centinela.ui.screens.GuardiaScreen
import cl.roang.centinela.ui.screens.GuardiasEnCasetaScreen
import cl.roang.centinela.ui.screens.InicioScreen
import cl.roang.centinela.ui.screens.LoginScreen
import cl.roang.centinela.ui.screens.ResumenScreen

@Composable
fun CentinelaApp(vm: CentinelaViewModel = viewModel()) {
    val contexto = LocalContext.current

    BackHandler {
        if (!vm.volver()) (contexto as? Activity)?.finish()
    }

    LaunchedEffect(vm.mensaje) {
        vm.mensaje?.let {
            Toast.makeText(contexto, it, Toast.LENGTH_SHORT).show()
            vm.mensaje = null
        }
    }

    val pantalla = vm.pantalla
    key(pantalla) {
        when (pantalla) {
            Pantalla.Login -> LoginScreen(vm)
            Pantalla.Inicio -> InicioScreen(vm)
            Pantalla.Datos -> DatosScreen(vm)
            Pantalla.CantidadCasetas -> CantidadCasetasScreen(vm)
            is Pantalla.GuardiasEnCaseta -> GuardiasEnCasetaScreen(vm, pantalla.c)
            is Pantalla.Guardia -> GuardiaScreen(vm, pantalla.c, pantalla.g)
            is Pantalla.FotosCaseta -> FotosCasetaScreen(vm, pantalla.c)
            Pantalla.Resumen -> ResumenScreen(vm)
            is Pantalla.Confirmacion -> ConfirmacionScreen(vm, pantalla.id, pantalla.envios)
            is Pantalla.Detalle -> DetalleScreen(vm, pantalla.id)
            Pantalla.BaseDatos -> BaseDatosScreen(vm)
        }
    }
}
