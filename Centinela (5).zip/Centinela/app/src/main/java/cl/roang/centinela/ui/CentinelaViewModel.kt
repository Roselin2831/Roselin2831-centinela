package cl.roang.centinela.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cl.roang.centinela.data.CasetaDraft
import cl.roang.centinela.data.CentinelaRepository
import cl.roang.centinela.data.Empresa
import cl.roang.centinela.data.FiscalizacionDetalle
import cl.roang.centinela.data.FiscalizacionResumen
import cl.roang.centinela.data.GuardiaDraft
import cl.roang.centinela.data.Instalacion
import cl.roang.centinela.data.TablaResultado
import cl.roang.centinela.data.Usuario
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Pantalla {
    data object Login : Pantalla
    data object Inicio : Pantalla
    data object Datos : Pantalla
    data object CantidadCasetas : Pantalla
    data class GuardiasEnCaseta(val c: Int) : Pantalla
    data class Guardia(val c: Int, val g: Int) : Pantalla
    data class FotosCaseta(val c: Int) : Pantalla
    data object Resumen : Pantalla
    data class Confirmacion(val id: Long, val envios: Int) : Pantalla
    data class Detalle(val id: Long) : Pantalla
    data object BaseDatos : Pantalla
}

class CentinelaViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = CentinelaRepository(app)

    var pantalla by mutableStateOf<Pantalla>(Pantalla.Login)
        private set
    var usuario by mutableStateOf<Usuario?>(null)
        private set
    var cargando by mutableStateOf(false)
        private set
    var errorLogin by mutableStateOf<String?>(null)
        private set
    var mensaje by mutableStateOf<String?>(null)

    // ---- Borrador de la fiscalización ----
    var empresas by mutableStateOf<List<Empresa>>(emptyList())
        private set
    var instalaciones by mutableStateOf<List<Instalacion>>(emptyList())
        private set
    var empresaSel by mutableStateOf<Empresa?>(null)
        private set
    var instalacionSel by mutableStateOf<Instalacion?>(null)
    var turno by mutableStateOf("Mañana")
    var casetas by mutableStateOf<List<CasetaDraft>>(emptyList())
        private set
    var observacionGeneral by mutableStateOf("")
    var enviarAps by mutableStateOf(true)

    val totalGuardias: Int get() = casetas.sumOf { it.guardias.size }
    val totalFotos: Int get() = casetas.sumOf { c -> c.fotos.size + c.guardias.sumOf { it.fotos.size } }

    // ---- Consultas ----
    var historial by mutableStateOf<List<FiscalizacionResumen>>(emptyList())
        private set
    var detalle by mutableStateOf<FiscalizacionDetalle?>(null)
        private set
    var tablas by mutableStateOf<List<Pair<String, Long>>>(emptyList())
        private set
    var consultaSql by mutableStateOf("SELECT * FROM fiscalizaciones ORDER BY id DESC")
    var resultadoSql by mutableStateOf<TablaResultado?>(null)
        private set
    var errorSql by mutableStateOf<String?>(null)
        private set

    // ================= Sesión =================

    fun login(user: String, clave: String) {
        if (cargando) return
        cargando = true
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) { repo.login(user, clave) }
            cargando = false
            if (res == null) {
                errorLogin = "Usuario o contraseña incorrectos"
            } else {
                errorLogin = null
                usuario = res
                irInicio()
            }
        }
    }

    fun cerrarSesion() {
        usuario = null
        limpiarBorrador()
        pantalla = Pantalla.Login
    }

    fun irInicio() {
        pantalla = Pantalla.Inicio
        val u = usuario ?: return
        viewModelScope.launch {
            historial = withContext(Dispatchers.IO) { repo.historial(u) }
        }
    }

    // ================= Flujo de fiscalización =================

    private fun limpiarBorrador() {
        empresaSel = null
        instalacionSel = null
        instalaciones = emptyList()
        turno = "Mañana"
        casetas = emptyList()
        observacionGeneral = ""
        enviarAps = true
    }

    fun nuevaFiscalizacion() {
        limpiarBorrador()
        pantalla = Pantalla.Datos
        viewModelScope.launch {
            empresas = withContext(Dispatchers.IO) { repo.empresas() }
        }
    }

    fun seleccionarEmpresa(empresa: Empresa) {
        empresaSel = empresa
        instalacionSel = null
        instalaciones = emptyList()
        val u = usuario ?: return
        viewModelScope.launch {
            instalaciones = withContext(Dispatchers.IO) { repo.instalaciones(empresa.id, u) }
        }
    }

    fun setCantidadCasetas(n: Int) {
        val actual = casetas
        casetas = (0 until n).map { i -> actual.getOrNull(i) ?: CasetaDraft(nombre = "Caseta ${i + 1}") }
    }

    fun setCantidadGuardias(c: Int, n: Int) = actualizarCaseta(c) { caseta ->
        caseta.copy(guardias = (0 until n).map { i -> caseta.guardias.getOrNull(i) ?: GuardiaDraft() })
    }

    fun actualizarCaseta(c: Int, cambio: (CasetaDraft) -> CasetaDraft) {
        casetas = casetas.toMutableList().also { it[c] = cambio(it[c]) }
    }

    fun actualizarGuardia(c: Int, g: Int, cambio: (GuardiaDraft) -> GuardiaDraft) = actualizarCaseta(c) { caseta ->
        caseta.copy(guardias = caseta.guardias.toMutableList().also { it[g] = cambio(it[g]) })
    }

    fun borrarArchivoFoto(ruta: String) {
        viewModelScope.launch(Dispatchers.IO) { File(ruta).delete() }
    }

    /** Copia una imagen de la galería a la carpeta privada de la app. */
    fun importarFoto(uri: Uri, alTerminar: (String) -> Unit) {
        viewModelScope.launch {
            val ruta = withContext(Dispatchers.IO) {
                try {
                    val destino = nuevoArchivoFoto(getApplication())
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { entrada ->
                        destino.outputStream().use { salida -> entrada.copyTo(salida) }
                    }
                    if (destino.length() > 0) destino.absolutePath else null
                } catch (e: Exception) {
                    null
                }
            }
            if (ruta != null) alTerminar(ruta) else mensaje = "No se pudo importar la imagen"
        }
    }

    fun irAPantalla(destino: Pantalla) {
        pantalla = destino
    }

    fun siguiente() {
        when (val p = pantalla) {
            Pantalla.Datos -> {
                if (empresaSel == null || instalacionSel == null) {
                    mensaje = "Selecciona empresa e instalación"
                    return
                }
                if (casetas.isEmpty()) setCantidadCasetas(1)
                pantalla = Pantalla.CantidadCasetas
            }
            Pantalla.CantidadCasetas -> pantalla = Pantalla.GuardiasEnCaseta(0)
            is Pantalla.GuardiasEnCaseta -> {
                if (casetas[p.c].nombre.isBlank()) {
                    mensaje = "Ingresa un nombre para la caseta"
                    return
                }
                pantalla = if (casetas[p.c].guardias.isNotEmpty()) Pantalla.Guardia(p.c, 0) else Pantalla.FotosCaseta(p.c)
            }
            is Pantalla.Guardia -> {
                val guardias = casetas[p.c].guardias
                if (guardias[p.g].nombre.isBlank()) {
                    mensaje = "Ingresa el nombre del guardia"
                    return
                }
                pantalla = if (p.g < guardias.lastIndex) Pantalla.Guardia(p.c, p.g + 1) else Pantalla.FotosCaseta(p.c)
            }
            is Pantalla.FotosCaseta ->
                pantalla = if (p.c < casetas.lastIndex) Pantalla.GuardiasEnCaseta(p.c + 1) else Pantalla.Resumen
            else -> Unit
        }
    }

    /** Devuelve false cuando ya no hay pantalla anterior (la app debe cerrarse). */
    fun volver(): Boolean {
        val anterior: Pantalla = when (val p = pantalla) {
            Pantalla.Login, Pantalla.Inicio -> return false
            Pantalla.Datos, Pantalla.BaseDatos, is Pantalla.Detalle, is Pantalla.Confirmacion -> {
                irInicio()
                return true
            }
            Pantalla.CantidadCasetas -> Pantalla.Datos
            is Pantalla.GuardiasEnCaseta ->
                if (p.c == 0) Pantalla.CantidadCasetas else Pantalla.FotosCaseta(p.c - 1)
            is Pantalla.Guardia ->
                if (p.g == 0) Pantalla.GuardiasEnCaseta(p.c) else Pantalla.Guardia(p.c, p.g - 1)
            is Pantalla.FotosCaseta -> {
                val guardias = casetas[p.c].guardias
                if (guardias.isEmpty()) Pantalla.GuardiasEnCaseta(p.c) else Pantalla.Guardia(p.c, guardias.lastIndex)
            }
            Pantalla.Resumen -> Pantalla.FotosCaseta(casetas.lastIndex)
        }
        pantalla = anterior
        return true
    }

    fun finalizar() {
        val u = usuario ?: return
        val e = empresaSel ?: return
        val i = instalacionSel ?: return
        if (cargando) return
        cargando = true
        viewModelScope.launch {
            try {
                val (id, envios) = withContext(Dispatchers.IO) {
                    repo.guardarFiscalizacion(u, e, i, turno, casetas, observacionGeneral, enviarAps)
                }
                limpiarBorrador()
                pantalla = Pantalla.Confirmacion(id, envios)
            } catch (ex: Exception) {
                mensaje = "Error al guardar: ${ex.message}"
            } finally {
                cargando = false
            }
        }
    }

    // ================= Historial y base de datos =================

    fun verDetalle(id: Long) {
        detalle = null
        pantalla = Pantalla.Detalle(id)
        viewModelScope.launch {
            detalle = withContext(Dispatchers.IO) { repo.detalle(id) }
        }
    }

    fun abrirBaseDatos() {
        pantalla = Pantalla.BaseDatos
        viewModelScope.launch {
            tablas = withContext(Dispatchers.IO) { repo.conteoTablas() }
        }
        ejecutarSql()
    }

    fun ejecutarSql(sql: String = consultaSql) {
        consultaSql = sql
        viewModelScope.launch {
            try {
                resultadoSql = withContext(Dispatchers.IO) { repo.consultar(sql) }
                errorSql = null
            } catch (e: Exception) {
                resultadoSql = null
                errorSql = e.message ?: "Error en la consulta"
            }
        }
    }
}
