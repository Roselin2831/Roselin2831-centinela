package cl.roang.centinela.ui.screens

import android.content.ActivityNotFoundException
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import cl.roang.centinela.ui.cargarMiniatura
import cl.roang.centinela.ui.nuevoArchivoFoto
import cl.roang.centinela.ui.theme.Azul
import cl.roang.centinela.ui.theme.AzulSuave
import cl.roang.centinela.ui.theme.Fondo
import cl.roang.centinela.ui.theme.Gris
import cl.roang.centinela.ui.theme.Navy
import cl.roang.centinela.ui.theme.Rojo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Estructura común: encabezado azul marino, contenido con scroll y botón inferior. */
@Composable
fun PantallaBase(
    titulo: String,
    subtitulo: String? = null,
    onVolver: (() -> Unit)? = null,
    acciones: @Composable RowScope.() -> Unit = {},
    inferior: (@Composable () -> Unit)? = null,
    contenido: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Navy)
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onVolver != null) {
                IconButton(onClick = onVolver) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
            } else {
                Spacer(Modifier.width(16.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(titulo, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (subtitulo != null) {
                    Text(subtitulo, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                }
            }
            acciones()
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = contenido
        )
        if (inferior != null) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) { inferior() }
        } else {
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
fun BotonPrincipal(
    texto: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    color: Color = Azul,
    cargando: Boolean = false,
    icono: ImageVector? = Icons.AutoMirrored.Filled.ArrowForward
) {
    Button(
        onClick = onClick,
        enabled = enabled && !cargando,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) {
        if (cargando) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            Text(texto, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (icono != null) {
                Spacer(Modifier.width(8.dp))
                Icon(icono, contentDescription = null)
            }
        }
    }
}

@Composable
fun Tarjeta(modifier: Modifier = Modifier, contenido: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = contenido)
    }
}

@Composable
fun IconoGrande(icono: ImageVector) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(AzulSuave),
            contentAlignment = Alignment.Center
        ) {
            Icon(icono, contentDescription = null, tint = Navy, modifier = Modifier.size(56.dp))
        }
    }
}

@Composable
fun Contador(valor: Int, onCambio: (Int) -> Unit, min: Int, max: Int) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalIconButton(onClick = { onCambio(valor - 1) }, enabled = valor > min, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Filled.Remove, contentDescription = "Restar")
        }
        Text(
            "$valor",
            fontSize = 36.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = 96.dp)
        )
        FilledTonalIconButton(onClick = { onCambio(valor + 1) }, enabled = valor < max, modifier = Modifier.size(56.dp)) {
            Icon(Icons.Filled.Add, contentDescription = "Sumar")
        }
    }
}

/** Campo de selección tipo "dropdown" con DropdownMenu estable. */
@Composable
fun <T> Selector(
    etiqueta: String,
    opciones: List<T>,
    seleccionado: T?,
    texto: (T) -> String,
    onSeleccion: (T) -> Unit,
    habilitado: Boolean = true
) {
    var abierto by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = seleccionado?.let(texto) ?: "",
            onValueChange = {},
            readOnly = true,
            enabled = habilitado,
            label = { Text(etiqueta) },
            placeholder = { Text("Seleccione...") },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(
            Modifier
                .matchParentSize()
                .clickable(enabled = habilitado) { abierto = true }
        )
        DropdownMenu(expanded = abierto, onDismissRequest = { abierto = false }) {
            if (opciones.isEmpty()) {
                DropdownMenuItem(text = { Text("Sin opciones disponibles") }, onClick = { abierto = false })
            }
            opciones.forEach { opcion ->
                DropdownMenuItem(
                    text = { Text(texto(opcion)) },
                    onClick = {
                        onSeleccion(opcion)
                        abierto = false
                    }
                )
            }
        }
    }
}

@Composable
fun FotoMiniatura(ruta: String, tamano: Dp = 88.dp, onEliminar: (() -> Unit)? = null) {
    val imagen by produceState<ImageBitmap?>(initialValue = null, ruta) {
        value = withContext(Dispatchers.IO) { cargarMiniatura(ruta) }
    }
    Box(
        Modifier
            .size(tamano)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFE3E8F0))
    ) {
        imagen?.let {
            Image(it, contentDescription = "Foto", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (onEliminar != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Rojo)
                    .clickable { onEliminar() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Close, contentDescription = "Eliminar foto", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun FilaFotos(fotos: List<String>, tamano: Dp = 72.dp) {
    if (fotos.isEmpty()) {
        Text("Sin fotos", color = Gris, fontSize = 13.sp)
    } else {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            fotos.forEach { FotoMiniatura(it, tamano) }
        }
    }
}

/** Toma fotos con la cámara del teléfono o las elige desde la galería (máximo [max]). */
@Composable
fun EditorFotos(
    fotos: List<String>,
    onAgregar: (String) -> Unit,
    onEliminar: (String) -> Unit,
    importar: (Uri, (String) -> Unit) -> Unit,
    titulo: String = "Fotos (máx. 5)",
    max: Int = 5
) {
    val contexto = LocalContext.current
    var rutaPendiente by rememberSaveable { mutableStateOf<String?>(null) }

    val camara = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val ruta = rutaPendiente
        if (ok && ruta != null && File(ruta).length() > 0) onAgregar(ruta) else ruta?.let { File(it).delete() }
        rutaPendiente = null
    }
    val galeria = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) importar(uri, onAgregar)
    }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(titulo, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text("${fotos.size}/$max", color = Gris)
    }
    if (fotos.isEmpty()) {
        Text("Aún no hay fotos.", color = Gris, fontSize = 13.sp)
    } else {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            fotos.forEach { ruta -> FotoMiniatura(ruta, onEliminar = { onEliminar(ruta) }) }
        }
    }
    if (fotos.size < max) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    try {
                        val archivo = nuevoArchivoFoto(contexto)
                        val uri = FileProvider.getUriForFile(contexto, "${contexto.packageName}.fileprovider", archivo)
                        rutaPendiente = archivo.absolutePath
                        camara.launch(uri)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(contexto, "No se encontró una app de cámara", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Cámara")
            }
            OutlinedButton(
                onClick = {
                    galeria.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Filled.PhotoLibrary, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Galería")
            }
        }
    }
}

@Composable
fun FilaDato(etiqueta: String, valor: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(etiqueta, color = Gris, modifier = Modifier.weight(1f))
        Text(valor, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.weight(1.4f))
    }
}

@Composable
fun Etiqueta(texto: String, fondo: Color, color: Color) {
    Text(
        texto,
        color = color,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(fondo)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun CeldaTabla(texto: String, encabezado: Boolean) {
    Text(
        texto,
        fontSize = 12.sp,
        fontWeight = if (encabezado) FontWeight.Bold else FontWeight.Normal,
        color = if (encabezado) Color.White else Color(0xFF111827),
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .width(150.dp)
            .background(if (encabezado) Navy else Color.White)
            .border(0.5.dp, Color(0xFFD1D5DB))
            .padding(8.dp)
    )
}
