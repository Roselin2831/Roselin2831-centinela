package cl.roang.centinela.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.roang.centinela.ui.CentinelaViewModel
import cl.roang.centinela.ui.theme.AzulSuave
import cl.roang.centinela.ui.theme.Gris
import cl.roang.centinela.ui.theme.Navy
import cl.roang.centinela.ui.theme.Rojo
import cl.roang.centinela.ui.theme.Verde
import cl.roang.centinela.ui.theme.VerdeSuave

@Composable
fun DetalleScreen(vm: CentinelaViewModel, id: Long) {
    val d = vm.detalle
    PantallaBase(titulo = "Fiscalización #$id", subtitulo = d?.resumen?.instalacion, onVolver = { vm.volver() }) {
        if (d == null) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            DetalleContenido(d)
        }
    }
}

@Composable
private fun DetalleContenido(d: cl.roang.centinela.data.FiscalizacionDetalle) {
    run {
        val r = d.resumen
        Tarjeta {
            FilaDato("Empresa", r.empresa)
            FilaDato("Instalación", r.instalacion)
            FilaDato("Supervisor", r.supervisor)
            FilaDato("Fecha", r.fecha)
            FilaDato("Turno", r.turno)
            FilaDato("Casetas", "${r.cantidadCasetas}")
            FilaDato("Guardias", "${r.cantidadGuardias}")
            FilaDato("Estado", r.estado)
            if (r.informacionAdicional.isNotBlank()) {
                Text("Información adicional", color = Gris)
                Text(r.informacionAdicional)
            }
        }
        d.casetas.forEach { caseta ->
            Tarjeta {
                Text(caseta.nombre, fontWeight = FontWeight.Bold, color = Navy, fontSize = 17.sp)
                if (caseta.observacion.isNotBlank()) Text("Obs: ${caseta.observacion}", color = Gris, fontSize = 13.sp)
                Text("Fotos de la caseta", fontWeight = FontWeight.SemiBold)
                FilaFotos(caseta.fotos)
                caseta.guardias.forEach { g ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AzulSuave.copy(alpha = 0.5f))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("Guardia: ${g.nombre}", fontWeight = FontWeight.SemiBold)
                        if (g.observacion.isNotBlank()) Text(g.observacion, color = Gris, fontSize = 13.sp)
                        FilaFotos(g.fotos, tamano = 64.dp)
                    }
                }
            }
        }
        Tarjeta {
            Text("Envíos al cliente APS", fontWeight = FontWeight.Bold, color = Navy)
            if (d.envios.isEmpty()) Text("No se solicitó envío.", color = Gris)
            d.envios.forEach { e ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.correo)
                        Text("${e.fecha} · intentos: ${e.intentos}", color = Gris, fontSize = 12.sp)
                    }
                    Etiqueta(e.estado, VerdeSuave, Verde)
                }
            }
        }
    }
}

@Composable
fun BaseDatosScreen(vm: CentinelaViewModel) {
    PantallaBase(titulo = "Base de datos", subtitulo = "MySQL simulada · centinela.db", onVolver = { vm.volver() }) {
        Text(
            "La app guarda todo en una base local con las mismas tablas y relaciones del esquema MySQL " +
                "(database/centinela_mysql.sql). Toca una tabla o escribe una consulta.",
            color = Gris,
            fontSize = 13.sp
        )
        Tarjeta {
            Text("Tablas", fontWeight = FontWeight.Bold, color = Navy)
            vm.tablas.forEach { (tabla, filas) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { vm.ejecutarSql("SELECT * FROM $tabla ORDER BY id DESC") }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(tabla, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Etiqueta("$filas filas", AzulSuave, Navy)
                }
            }
        }
        Tarjeta {
            Text("Consulta SQL (solo lectura)", fontWeight = FontWeight.Bold, color = Navy)
            OutlinedTextField(
                value = vm.consultaSql,
                onValueChange = { vm.consultaSql = it },
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { vm.ejecutarSql() }) { Text("Ejecutar") }
                OutlinedButton(onClick = { vm.ejecutarSql("SHOW TABLES") }) { Text("SHOW TABLES") }
                OutlinedButton(onClick = { vm.ejecutarSql("DESCRIBE fiscalizaciones") }) { Text("DESCRIBE") }
            }
            vm.errorSql?.let { Text(it, color = Rojo) }
        }
        vm.resultadoSql?.let { t ->
            Text("${t.filas.size} fila(s)", color = Gris, fontSize = 13.sp)
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                Row { t.columnas.forEach { CeldaTabla(it, encabezado = true) } }
                t.filas.forEach { fila -> Row { fila.forEach { CeldaTabla(it, encabezado = false) } } }
            }
        }
    }
}
