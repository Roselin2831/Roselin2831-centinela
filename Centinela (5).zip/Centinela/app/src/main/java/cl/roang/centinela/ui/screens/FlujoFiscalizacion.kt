package cl.roang.centinela.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.roang.centinela.ui.CentinelaViewModel
import cl.roang.centinela.ui.Pantalla
import cl.roang.centinela.ui.theme.Azul
import cl.roang.centinela.ui.theme.AzulSuave
import cl.roang.centinela.ui.theme.Gris
import cl.roang.centinela.ui.theme.Navy
import cl.roang.centinela.ui.theme.Verde
import cl.roang.centinela.ui.theme.VerdeSuave
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- Paso 1: datos de la fiscalización ----------
@Composable
fun DatosScreen(vm: CentinelaViewModel) {
    PantallaBase(
        titulo = "Nueva fiscalización",
        subtitulo = "Paso 1 · Datos de la fiscalización",
        onVolver = { vm.volver() },
        inferior = {
            BotonPrincipal(
                "Siguiente",
                onClick = { vm.siguiente() },
                enabled = vm.empresaSel != null && vm.instalacionSel != null
            )
        }
    ) {
        Tarjeta {
            Selector(
                etiqueta = "Empresa",
                opciones = vm.empresas,
                seleccionado = vm.empresaSel,
                texto = { it.nombre },
                onSeleccion = { vm.seleccionarEmpresa(it) }
            )
            Selector(
                etiqueta = "Instalación",
                opciones = vm.instalaciones,
                seleccionado = vm.instalacionSel,
                texto = { it.nombre },
                onSeleccion = { vm.instalacionSel = it },
                habilitado = vm.empresaSel != null
            )
            vm.instalacionSel?.let { Text(it.direccion, color = Gris, fontSize = 13.sp) }
        }
        Tarjeta {
            Text("Turno", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OpcionTurno("Mañana", Icons.Filled.WbSunny, vm.turno == "Mañana", Modifier.weight(1f)) { vm.turno = "Mañana" }
                OpcionTurno("Noche", Icons.Filled.NightsStay, vm.turno == "Noche", Modifier.weight(1f)) { vm.turno = "Noche" }
            }
        }
        Tarjeta {
            FilaDato("Supervisor", vm.usuario?.nombre ?: "")
            FilaDato("Fecha", SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US).format(Date()))
        }
    }
}

@Composable
private fun OpcionTurno(texto: String, icono: ImageVector, activo: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (activo) Azul else AzulSuave)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icono, contentDescription = null, tint = if (activo) Color.White else Navy)
        Spacer(Modifier.height(4.dp))
        Text(texto, color = if (activo) Color.White else Navy, fontWeight = FontWeight.SemiBold)
    }
}

// ---------- Paso 2: cantidad de casetas ----------
@Composable
fun CantidadCasetasScreen(vm: CentinelaViewModel) {
    PantallaBase(
        titulo = "Cantidad de casetas",
        subtitulo = "Paso 2 · ${vm.instalacionSel?.nombre ?: ""}",
        onVolver = { vm.volver() },
        inferior = { BotonPrincipal("Siguiente", onClick = { vm.siguiente() }) }
    ) {
        Spacer(Modifier.height(24.dp))
        IconoGrande(Icons.Filled.HomeWork)
        Text(
            "¿Cuántas casetas desea fiscalizar?",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Contador(vm.casetas.size, onCambio = { vm.setCantidadCasetas(it) }, min = 1, max = 20)
    }
}

// ---------- Paso 3: guardias de la caseta ----------
@Composable
fun GuardiasEnCasetaScreen(vm: CentinelaViewModel, c: Int) {
    val caseta = vm.casetas[c]
    PantallaBase(
        titulo = "Caseta ${c + 1} de ${vm.casetas.size}",
        subtitulo = vm.instalacionSel?.nombre,
        onVolver = { vm.volver() },
        inferior = { BotonPrincipal("Siguiente", onClick = { vm.siguiente() }) }
    ) {
        IconoGrande(Icons.Filled.HomeWork)
        Text(
            "Caseta N° ${c + 1}",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = caseta.nombre,
            onValueChange = { nuevo -> vm.actualizarCaseta(c) { it.copy(nombre = nuevo) } },
            label = { Text("Nombre o ubicación de la caseta") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "¿Cuántos guardias hay en esta caseta?",
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Contador(caseta.guardias.size, onCambio = { vm.setCantidadGuardias(c, it) }, min = 0, max = 10)
    }
}

// ---------- Paso 4: registro de cada guardia ----------
@Composable
fun GuardiaScreen(vm: CentinelaViewModel, c: Int, g: Int) {
    val caseta = vm.casetas[c]
    val guardia = caseta.guardias[g]
    PantallaBase(
        titulo = "Caseta ${c + 1} · Guardia ${g + 1} de ${caseta.guardias.size}",
        subtitulo = caseta.nombre,
        onVolver = { vm.volver() },
        inferior = { BotonPrincipal("Siguiente", onClick = { vm.siguiente() }, enabled = guardia.nombre.isNotBlank()) }
    ) {
        IconoGrande(Icons.Filled.Person)
        Tarjeta {
            OutlinedTextField(
                value = guardia.nombre,
                onValueChange = { nuevo -> vm.actualizarGuardia(c, g) { it.copy(nombre = nuevo) } },
                label = { Text("Nombre del guardia *") },
                placeholder = { Text("Ej. Juan Pérez") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = guardia.observacion,
                onValueChange = { nuevo -> vm.actualizarGuardia(c, g) { it.copy(observacion = nuevo.take(200)) } },
                label = { Text("Observación (opcional)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Tarjeta {
            EditorFotos(
                titulo = "Fotos del guardia (máx. 5)",
                fotos = guardia.fotos,
                onAgregar = { ruta -> vm.actualizarGuardia(c, g) { it.copy(fotos = (it.fotos + ruta).take(5)) } },
                onEliminar = { ruta ->
                    vm.actualizarGuardia(c, g) { it.copy(fotos = it.fotos - ruta) }
                    vm.borrarArchivoFoto(ruta)
                },
                importar = vm::importarFoto
            )
        }
    }
}

// ---------- Paso 5: fotos y observaciones de la caseta ----------
@Composable
fun FotosCasetaScreen(vm: CentinelaViewModel, c: Int) {
    val caseta = vm.casetas[c]
    val esUltima = c == vm.casetas.lastIndex
    PantallaBase(
        titulo = "Caseta ${c + 1} · Fotos y observaciones",
        subtitulo = caseta.nombre,
        onVolver = { vm.volver() },
        inferior = {
            BotonPrincipal(if (esUltima) "Ir al resumen" else "Siguiente caseta", onClick = { vm.siguiente() })
        }
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(VerdeSuave)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Verde, modifier = Modifier.size(40.dp))
            Text("Guardias registrados: ${caseta.guardias.size}", fontWeight = FontWeight.Bold, color = Navy)
            if (caseta.guardias.isNotEmpty()) {
                Text(caseta.guardias.joinToString(", ") { it.nombre }, color = Gris, textAlign = TextAlign.Center)
            }
        }
        Tarjeta {
            EditorFotos(
                titulo = "Fotos de la caseta (máx. 5)",
                fotos = caseta.fotos,
                onAgregar = { ruta -> vm.actualizarCaseta(c) { it.copy(fotos = (it.fotos + ruta).take(5)) } },
                onEliminar = { ruta ->
                    vm.actualizarCaseta(c) { it.copy(fotos = it.fotos - ruta) }
                    vm.borrarArchivoFoto(ruta)
                },
                importar = vm::importarFoto
            )
        }
        Tarjeta {
            OutlinedTextField(
                value = caseta.observacion,
                onValueChange = { nuevo -> vm.actualizarCaseta(c) { it.copy(observacion = nuevo.take(300)) } },
                label = { Text("Observación de la caseta") },
                placeholder = { Text("Ej. Caseta en orden, sin novedades") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------- Paso 6: resumen y envío ----------
@Composable
fun ResumenScreen(vm: CentinelaViewModel) {
    PantallaBase(
        titulo = "Resumen",
        subtitulo = "Revisa la información antes de finalizar",
        onVolver = { vm.volver() },
        inferior = {
            BotonPrincipal(
                "Finalizar fiscalización",
                onClick = { vm.finalizar() },
                color = Verde,
                cargando = vm.cargando,
                icono = Icons.Filled.Check
            )
        }
    ) {
        Tarjeta {
            FilaDato("Empresa", vm.empresaSel?.nombre ?: "")
            FilaDato("Instalación", vm.instalacionSel?.nombre ?: "")
            FilaDato("Supervisor", vm.usuario?.nombre ?: "")
            FilaDato("Turno", vm.turno)
            FilaDato("Casetas", "${vm.casetas.size}")
            FilaDato("Guardias", "${vm.totalGuardias}")
            FilaDato("Fotos", "${vm.totalFotos}")
        }
        vm.casetas.forEachIndexed { i, caseta ->
            Tarjeta {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(caseta.nombre, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f))
                    Etiqueta("${caseta.fotos.size} fotos", AzulSuave, Navy)
                }
                if (caseta.guardias.isEmpty()) Text("Sin guardias", color = Gris)
                caseta.guardias.forEach { g ->
                    Text("• ${g.nombre}  (${g.fotos.size} fotos)")
                }
                if (caseta.observacion.isNotBlank()) Text("Obs: ${caseta.observacion}", color = Gris, fontSize = 13.sp)
                OutlinedButton(onClick = { vm.irAPantalla(Pantalla.GuardiasEnCaseta(i)) }) { Text("Editar caseta") }
            }
        }
        Tarjeta {
            Text("Información adicional", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = vm.observacionGeneral,
                onValueChange = { vm.observacionGeneral = it.take(500) },
                placeholder = { Text("Ej. Todo en orden, sin novedades.") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Text("${vm.observacionGeneral.length}/500", color = Gris, fontSize = 12.sp, modifier = Modifier.align(Alignment.End))
        }
        Tarjeta {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CloudUpload, contentDescription = null, tint = Navy)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Enviar al cliente APS", fontWeight = FontWeight.SemiBold)
                    Text("Se registra el envío en la tabla envios_aps (simulado).", color = Gris, fontSize = 12.sp)
                }
                Switch(checked = vm.enviarAps, onCheckedChange = { vm.enviarAps = it })
            }
        }
    }
}

// ---------- Paso 7: confirmación ----------
@Composable
fun ConfirmacionScreen(vm: CentinelaViewModel, id: Long, envios: Int) {
    PantallaBase(
        titulo = "Confirmación",
        inferior = { BotonPrincipal("Finalizar", onClick = { vm.irInicio() }, icono = null) }
    ) {
        Spacer(Modifier.height(40.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(Verde)
                    .border(6.dp, VerdeSuave, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
            }
        }
        Text(
            if (envios > 0) "¡Informe enviado!" else "¡Fiscalización registrada!",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "La fiscalización #$id se guardó correctamente en la base de datos." +
                if (envios > 0) " Se simuló el envío a $envios destinatario(s) APS." else "",
            color = Gris,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { vm.verDetalle(id) }, modifier = Modifier.fillMaxWidth()) {
            Text("Ver detalle")
        }
    }
}
