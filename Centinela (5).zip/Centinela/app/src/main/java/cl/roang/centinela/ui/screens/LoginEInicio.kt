package cl.roang.centinela.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cl.roang.centinela.ui.CentinelaViewModel
import cl.roang.centinela.ui.theme.Azul
import cl.roang.centinela.ui.theme.AzulSuave
import cl.roang.centinela.ui.theme.Gris
import cl.roang.centinela.ui.theme.Navy
import cl.roang.centinela.ui.theme.NavyClaro
import cl.roang.centinela.ui.theme.Verde
import cl.roang.centinela.ui.theme.VerdeSuave

@Composable
fun LoginScreen(vm: CentinelaViewModel) {
    var usuario by rememberSaveable { mutableStateOf("") }
    var clave by rememberSaveable { mutableStateOf("") }
    var verClave by rememberSaveable { mutableStateOf(false) }

    val colores = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedBorderColor = Color.White,
        unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
        focusedLabelColor = Color.White,
        unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
        cursorColor = Color.White,
        focusedLeadingIconColor = Color.White,
        unfocusedLeadingIconColor = Color.White.copy(alpha = 0.7f),
        focusedTrailingIconColor = Color.White,
        unfocusedTrailingIconColor = Color.White.copy(alpha = 0.7f)
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, NavyClaro)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier
                .size(112.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Shield, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
        }
        Text("CENTINELA", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Fiscalización de Instalaciones", color = Color.White, fontSize = 16.sp)
            Text("Seguridad en Terreno", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = usuario,
            onValueChange = { usuario = it },
            label = { Text("Usuario") },
            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
            singleLine = true,
            colors = colores,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = clave,
            onValueChange = { clave = it },
            label = { Text("Contraseña") },
            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
            trailingIcon = {
                IconButton(onClick = { verClave = !verClave }) {
                    Icon(
                        if (verClave) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (verClave) "Ocultar" else "Mostrar"
                    )
                }
            },
            visualTransformation = if (verClave) VisualTransformation.None else PasswordVisualTransformation(),
            singleLine = true,
            colors = colores,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { vm.login(usuario, clave) }),
            modifier = Modifier.fillMaxWidth()
        )
        vm.errorLogin?.let { Text(it, color = Color(0xFFFFB4AB), fontWeight = FontWeight.SemiBold) }

        BotonPrincipal(
            texto = "INGRESAR",
            onClick = { vm.login(usuario, clave) },
            enabled = usuario.isNotBlank() && clave.isNotBlank(),
            cargando = vm.cargando,
            icono = null
        )

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.1f))
                .padding(14.dp)
        ) {
            Text("Usuarios de prueba", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("supervisor / 1234", color = Color.White.copy(alpha = 0.85f))
            Text("admin / admin123", color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.height(8.dp))
        Text("Tu seguridad, nuestro compromiso", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
    }
}

@Composable
fun InicioScreen(vm: CentinelaViewModel) {
    val usuario = vm.usuario ?: return
    PantallaBase(
        titulo = "Hola, ${usuario.nombre}",
        subtitulo = if (usuario.esAdmin) "Administrador · ve todas las fiscalizaciones" else "Supervisor",
        acciones = {
            IconButton(onClick = { vm.cerrarSesion() }) {
                Icon(Icons.Filled.PowerSettingsNew, contentDescription = "Cerrar sesión", tint = Color.White)
            }
        }
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Navy, Azul)))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Nueva fiscalización", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(
                "Registra casetas, guardias y evidencia fotográfica de la instalación.",
                color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(Modifier.height(4.dp))
            BotonPrincipal("Comenzar", onClick = { vm.nuevaFiscalizacion() }, color = Color.White.copy(alpha = 0.22f))
        }

        OutlinedButton(onClick = { vm.abrirBaseDatos() }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Icon(Icons.Filled.Storage, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Ver base de datos (MySQL simulada)")
        }

        Text("Historial de fiscalizaciones", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Navy)
        if (vm.historial.isEmpty()) {
            Tarjeta { Text("Aún no hay fiscalizaciones registradas. Crea la primera con el botón Comenzar.", color = Gris) }
        }
        vm.historial.forEach { f ->
            Tarjeta(Modifier.clickable { vm.verDetalle(f.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("#${f.id} · ${f.instalacion}", fontWeight = FontWeight.Bold, color = Navy)
                        Text(f.empresa, color = Gris, fontSize = 13.sp)
                        Text("${f.fecha} · Turno ${f.turno}", color = Gris, fontSize = 13.sp)
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = Gris)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Etiqueta("${f.cantidadCasetas} casetas", AzulSuave, Navy)
                    Etiqueta("${f.cantidadGuardias} guardias", AzulSuave, Navy)
                    if (f.enviarAps) Etiqueta("Enviado APS", VerdeSuave, Verde)
                }
                if (usuario.esAdmin) Text("Supervisor: ${f.supervisor}", fontSize = 12.sp, color = Gris)
            }
        }
    }
}
