package cl.roang.centinela.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B2A5B)
val NavyClaro = Color(0xFF123E85)
val Azul = Color(0xFF1677F2)
val AzulSuave = Color(0xFFDCE8FF)
val Verde = Color(0xFF1E9E4A)
val VerdeSuave = Color(0xFFE3F5E9)
val Fondo = Color(0xFFF3F6FB)
val Gris = Color(0xFF6B7280)
val Rojo = Color(0xFFE53935)

private val Esquema = lightColorScheme(
    primary = Azul,
    onPrimary = Color.White,
    primaryContainer = AzulSuave,
    onPrimaryContainer = Navy,
    secondary = Navy,
    onSecondary = Color.White,
    secondaryContainer = AzulSuave,
    onSecondaryContainer = Navy,
    background = Fondo,
    surface = Color.White,
    onSurface = Color(0xFF111827),
    error = Rojo
)

@Composable
fun CentinelaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Esquema, content = content)
}
