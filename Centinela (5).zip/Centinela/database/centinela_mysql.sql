-- =====================================================================
--  CENTINELA · Fiscalización de Seguridad en Terreno
--  Esquema MySQL 8 (mismo modelo que usa la app de forma local/simulada)
--  Uso: mysql -u root -p < centinela_mysql.sql   (o importar en phpMyAdmin / Workbench)
-- =====================================================================

DROP DATABASE IF EXISTS centinela;
CREATE DATABASE centinela CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE centinela;

-- Usuarios del sistema (administradores y supervisores)
CREATE TABLE usuarios (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    nombre        VARCHAR(120) NOT NULL,
    usuario       VARCHAR(60)  NOT NULL UNIQUE,
    password_hash CHAR(64)     NOT NULL,           -- SHA-256 (en producción usar bcrypt/argon2)
    rol           ENUM('admin','supervisor') NOT NULL,
    activo        TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- Empresas clientes
CREATE TABLE empresas (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    rut    VARCHAR(15)  NOT NULL UNIQUE,
    activo TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- Instalaciones de cada empresa
CREATE TABLE instalaciones (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT          NOT NULL,
    nombre     VARCHAR(150) NOT NULL,
    direccion  VARCHAR(255),
    activo     TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT fk_inst_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id)
) ENGINE=InnoDB;

-- Asignación de supervisores a instalaciones
CREATE TABLE supervisor_instalaciones (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    supervisor_id  INT        NOT NULL,
    instalacion_id INT        NOT NULL,
    activo         TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY uq_sup_inst (supervisor_id, instalacion_id),
    CONSTRAINT fk_si_usuario     FOREIGN KEY (supervisor_id)  REFERENCES usuarios(id),
    CONSTRAINT fk_si_instalacion FOREIGN KEY (instalacion_id) REFERENCES instalaciones(id)
) ENGINE=InnoDB;

-- Registro principal de cada visita
CREATE TABLE fiscalizaciones (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    supervisor_id         INT      NOT NULL,
    empresa_id            INT      NOT NULL,
    instalacion_id        INT      NOT NULL,
    turno                 ENUM('Mañana','Noche') NOT NULL,
    fecha_fiscalizacion   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cantidad_guardias     INT      NOT NULL DEFAULT 0,
    cantidad_casetas      INT      NOT NULL DEFAULT 0,
    informacion_adicional VARCHAR(500),
    estado                VARCHAR(20) NOT NULL DEFAULT 'FINALIZADA',
    enviar_aps            TINYINT(1)  NOT NULL DEFAULT 0,
    CONSTRAINT fk_f_supervisor  FOREIGN KEY (supervisor_id)  REFERENCES usuarios(id),
    CONSTRAINT fk_f_empresa     FOREIGN KEY (empresa_id)     REFERENCES empresas(id),
    CONSTRAINT fk_f_instalacion FOREIGN KEY (instalacion_id) REFERENCES instalaciones(id)
) ENGINE=InnoDB;

-- Casetas revisadas en la fiscalización
CREATE TABLE casetas_fiscalizacion (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    fiscalizacion_id INT          NOT NULL,
    nombre           VARCHAR(120) NOT NULL,
    observacion      VARCHAR(300),
    CONSTRAINT fk_c_fiscalizacion FOREIGN KEY (fiscalizacion_id) REFERENCES fiscalizaciones(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Guardias registrados (cada guardia pertenece a una caseta)
CREATE TABLE guardias_fiscalizacion (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    fiscalizacion_id INT          NOT NULL,
    caseta_id        INT          NULL,             -- columna agregada para el flujo "por caseta"
    nombre           VARCHAR(120) NOT NULL,
    observacion      VARCHAR(200),
    CONSTRAINT fk_g_fiscalizacion FOREIGN KEY (fiscalizacion_id) REFERENCES fiscalizaciones(id) ON DELETE CASCADE,
    CONSTRAINT fk_g_caseta        FOREIGN KEY (caseta_id)        REFERENCES casetas_fiscalizacion(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Fotografías de cada guardia (máx. 5, se controla en la app)
CREATE TABLE fotos_guardias (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    guardia_id INT          NOT NULL,
    ruta_foto  VARCHAR(255) NOT NULL,
    fecha_foto DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fg_guardia FOREIGN KEY (guardia_id) REFERENCES guardias_fiscalizacion(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Fotografías de cada caseta (máx. 5)
CREATE TABLE fotos_casetas (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    caseta_id  INT          NOT NULL,
    ruta_foto  VARCHAR(255) NOT NULL,
    fecha_foto DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fc_caseta FOREIGN KEY (caseta_id) REFERENCES casetas_fiscalizacion(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Correos de las personas que reciben el informe (APS)
CREATE TABLE destinatarios_aps (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    empresa_id     INT          NOT NULL,
    instalacion_id INT          NULL,               -- NULL = todas las instalaciones de la empresa
    nombre         VARCHAR(120) NOT NULL,
    correo         VARCHAR(150) NOT NULL,
    activo         TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT fk_d_empresa     FOREIGN KEY (empresa_id)     REFERENCES empresas(id),
    CONSTRAINT fk_d_instalacion FOREIGN KEY (instalacion_id) REFERENCES instalaciones(id)
) ENGINE=InnoDB;

-- Historial de envíos de informes APS
CREATE TABLE envios_aps (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    fiscalizacion_id INT          NOT NULL,
    destinatario_id  INT          NULL,
    correo_destino   VARCHAR(150) NOT NULL,
    estado           ENUM('PENDIENTE','ENVIADO','ERROR') NOT NULL DEFAULT 'PENDIENTE',
    intentos         INT          NOT NULL DEFAULT 0,
    fecha_envio      DATETIME     NULL,
    ultimo_error     VARCHAR(255) NULL,
    CONSTRAINT fk_e_fiscalizacion FOREIGN KEY (fiscalizacion_id) REFERENCES fiscalizaciones(id) ON DELETE CASCADE,
    CONSTRAINT fk_e_destinatario  FOREIGN KEY (destinatario_id)  REFERENCES destinatarios_aps(id)
) ENGINE=InnoDB;

-- =========================== DATOS DE PRUEBA ===========================

INSERT INTO usuarios (nombre, usuario, password_hash, rol) VALUES
('Administrador CENTINELA', 'admin',      SHA2('admin123', 256), 'admin'),
('Supervisor Demo',         'supervisor', SHA2('1234', 256),     'supervisor');

INSERT INTO empresas (nombre, rut) VALUES
('Seguridad Total Ltda.',    '76.111.111-1'),
('Rentas Chile S.A.',        '76.222.222-2'),
('Servicios Integrales SpA', '76.333.333-3'),
('Grupo Protección Ltda.',   '76.444.444-4');

INSERT INTO instalaciones (empresa_id, nombre, direccion) VALUES
(1, 'Casa Matriz',          'Av. Apoquindo 4500, Las Condes'),
(1, 'Planta Industrial',    'Camino Lo Boza 120, Pudahuel'),
(1, 'Centro Logístico',     'Av. Américo Vespucio 1500, Quilicura'),
(2, 'Sucursal Santiago',    'Av. Libertador B. O''Higgins 1234, Santiago'),
(2, 'Sucursal Valparaíso',  'Av. Brasil 2100, Valparaíso'),
(3, 'Sucursal Concepción',  'Calle Barros Arana 800, Concepción'),
(3, 'Bodega Central',       'Av. Departamental 3300, San Joaquín'),
(4, 'Edificio Corporativo', 'Av. Providencia 2000, Providencia'),
(4, 'Condominio Los Robles','Los Robles 450, La Florida');

INSERT INTO supervisor_instalaciones (supervisor_id, instalacion_id) VALUES
(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8);

INSERT INTO destinatarios_aps (empresa_id, instalacion_id, nombre, correo) VALUES
(1, NULL, 'Jefatura APS Seguridad Total',  'aps@seguridadtotal.demo'),
(2, NULL, 'Operaciones Rentas Chile',      'aps@rentaschile.demo'),
(3, NULL, 'Control Servicios Integrales',  'aps@serviciosintegrales.demo'),
(4, NULL, 'Gerencia Grupo Protección',     'aps@grupoproteccion.demo');

-- Consulta de ejemplo: resumen de fiscalizaciones
-- SELECT f.id, e.nombre AS empresa, i.nombre AS instalacion, f.turno, f.fecha_fiscalizacion,
--        f.cantidad_casetas, f.cantidad_guardias, f.estado
-- FROM fiscalizaciones f
-- JOIN empresas e ON e.id = f.empresa_id
-- JOIN instalaciones i ON i.id = f.instalacion_id
-- ORDER BY f.id DESC;
